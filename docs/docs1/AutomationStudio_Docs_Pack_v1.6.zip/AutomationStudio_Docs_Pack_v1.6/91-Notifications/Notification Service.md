# Notifications

Channels - VS Code - Email - Microsoft Teams - Slack - Webhooks

Events - Run completed - Run failed - Review requested - Plugin updates
