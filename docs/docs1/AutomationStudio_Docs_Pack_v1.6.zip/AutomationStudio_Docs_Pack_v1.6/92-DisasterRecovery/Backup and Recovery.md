# Backup and Recovery

Back Up - Project metadata - Object repository - Configuration - Reports

Recovery - Restore project - Validate integrity - Rebuild indexes
