# Enterprise Features

Capabilities - Multi-user workspaces - Role-based permissions - Audit
history - Approval workflows - Central artifact repository - License
management

Future - SSO - SCIM provisioning - Policy enforcement
