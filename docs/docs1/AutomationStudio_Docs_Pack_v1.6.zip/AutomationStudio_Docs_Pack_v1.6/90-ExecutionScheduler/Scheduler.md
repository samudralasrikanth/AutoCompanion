# Execution Scheduler

Modes - Manual - Scheduled - Triggered by Git - Triggered by API

Features - Queues - Priorities - Retry policy - Resource allocation
