# Governance

Roles - Administrator - Framework Owner - Automation Engineer -
Reviewer - Auditor

Policies - Code review required - Signed releases - Documentation
updated per release
